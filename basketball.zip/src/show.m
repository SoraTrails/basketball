function show(video, n)
	ima=read(video,n);
	imshow(ima);
