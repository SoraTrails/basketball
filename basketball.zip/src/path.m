%路径
% which fliplr -all

% restoredefaultpath
% rehash toolboxcache
% savepath

% cd F:\matlab\toolbox\bnt;
% addpath(genpathKPM(pwd));

% F:\matlab\toolbox\bnt\KPMtools\strsplit.m
% F:\matlab\toolbox\bnt\KPMtools\assert.m

file_path = 'F:\basketball\test1.mkv';%29个镜�?